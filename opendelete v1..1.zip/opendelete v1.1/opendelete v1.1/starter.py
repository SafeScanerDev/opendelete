import os
import time
import subprocess
from colorama import init, Fore, Style

# Инициализация цветов
init(autoreset=True)

# Константы
LOG_FILE = "scan_report.txt"
TARGET_DIR = os.path.join(os.environ['USERPROFILE'], 'Desktop')

# База сигнатур (разбита, чтобы сканер не детектил сам себя)
SIGNATURES = [
    "power" + "shell", "bypass", "hidden", "rmdir", 
    "taskkill", "Cookies", "LoginData", "WebData", "LocalState"
]

def draw_shield(status="LOCKED", color=Fore.CYAN):
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"""
{color}          .----------.
{color}         /    [{status}]    \\
{color}        |      /\\      |      ------>
{color}        |     /  \\     |
{color}         \\    \\  /    /
{color}          \\    \\/    /
{color}           '--------'
    """)

def fatal_kill():
    draw_shield("FATAL", Fore.RED)
    print(Fore.RED + "[!] ЗАПУСК ФАТАЛЬНОГО УНИЧТОЖЕНИЯ...")
    
    processes = ["wscript.exe", "cscript.exe", "powershell.exe"]
    for proc in processes:
        subprocess.run(f"taskkill /f /im {proc} /t", shell=True, capture_output=True)
        print(Fore.YELLOW + f"[*] Попытка завершения {proc}...")

    # Очистка Temp
    temp_path = os.environ.get('TEMP')
    if temp_path:
        print(Fore.YELLOW + "[*] Очистка временных файлов...")
        subprocess.run(f"del /f /q /s {temp_path}\\*.*", shell=True, capture_output=True)
    
    print(Fore.GREEN + "\n[OK] Система очищена.")
    input("\nНажмите Enter для выхода в меню...")

def real_scanner():
    draw_shield("SCAN", Fore.BLUE)
    print(Fore.BLUE + f"[!] СКАНИРОВАНИЕ: {TARGET_DIR}")
    print("-" * 40)
    
    found_count = 0
    extensions = ('.exe', '.bat', '.py', '.ps1', '.vbs', '.cmd', '.txt')
    
    with open(LOG_FILE, "w", encoding="utf-8") as log:
        log.write(f"ОТЧЕТ СКАНЕРА - {time.ctime()}\n\n")
        
        for root, dirs, files in os.walk(TARGET_DIR):
            for file in files:
                if file.lower().endswith(extensions):
                    file_path = os.path.join(root, file)
                    
                    # Пропускаем сам скрипт и лог
                    if "shield.py" in file_path or LOG_FILE in file_path:
                        continue
                    
                    try:
                        print(f"{Fore.WHITE}[СКАН]: {file}")
                        with open(file_path, 'r', errors='ignore') as f:
                            content = f.read()
                            for sig in SIGNATURES:
                                if sig in content:
                                    found_count += 1
                                    print(f"{Fore.RED}[!!!] НАЙДЕНО: {file} (Причина: {sig})")
                                    log.write(f"ОБЪЕКТ: {file}\nПУТЬ: {file_path}\nПРИЧИНА: {sig}\n\n")
                                    break
                    except Exception:
                        continue

    print("-" * 40)
    print(f"{Fore.GREEN}Сканирование завершено. Найдено угроз: {found_count}")
    if found_count > 0:
        os.startfile(LOG_FILE)
    input("\nНажмите Enter...")

def login():
    while True:
        draw_shield("LOCKED", Fore.CYAN)
        code = input(f"{Fore.WHITE}      ВВЕДИТЕ КОД ДОСТУПА: {Fore.YELLOW}")
        if code == "N9sa-": return "30 дней"
        if code == "Nopa233-": return "90 дней"
        if code == "3333": return "Навсегда"
        print(Fore.RED + "      [!] ОШИБКА: НЕВЕРНЫЙ КОД")
        time.sleep(1.5)

def main():
    term = login()
    while True:
        draw_shield(" OPEN ", Fore.GREEN)
        print(f"{Fore.CYAN}========================================")
        print(f"{Fore.WHITE} 1. {Fore.RED}Фатальное уничтожение")
        print(f"{Fore.WHITE} 2. {Fore.BLUE}Сканер (Python Engine)")
        print(f"{Fore.WHITE} 3. {Fore.YELLOW}Подписка: {term}")
        print(f"{Fore.WHITE} 4. Выход")
        print(f"{Fore.CYAN}========================================\n")
        
        choice = input(Fore.YELLOW + "Выбор > ")
        if choice == "1": fatal_kill()
        elif choice == "2": real_scanner()
        elif choice == "3": print(f"\nЛицензия: {term}"); input()
        elif choice == "4": break

if __name__ == "__main__":
    main()
