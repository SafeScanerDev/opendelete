🛡️ Security Shield System v1.3

Security Shield System is a high-performance console utility designed for rapid system cleanup and signature-based file analysis. This tool is engineered to detect traces of stealers, miners, and malicious scripts, as well as to forcefully terminate suspicious background processes.
🔑 Access System (License Keys)
The software is protected by an activation code system. Depending on the code entered, the user is granted different subscription terms:
N9sa- — 30 Days access.
Nopa233- — 90 Days access.
3333 — Lifetime License (Unlimited).
🚀 Core Functionality
1. ⚡ Fatal Destruction (Fatal Kill)
An emergency cleanup mode. Upon activation, the program:
Forcefully terminates interpreter processes (wscript, cscript, powershell), which are used by 90% of modern script-based malware.
Clears the Startup directory, removing threats that have established persistence in the system.
Wipes Temporary folders (TEMP), destroying downloaded malicious modules and their configurations.
2. 🔍 Deep Scanner
Intelligent code analysis for the following file extensions: .exe, .bat, .py, .ps1, .vbs, .cmd.
Signature Database: Searches for evidence of browser data theft (Login Data, Cookies), security policy bypasses, and hidden system manipulations.
Anti-Self-Detect: An integrated code-masking system ensures the scanner does not trigger on its own source code.
Auto-Reporting: Generates a detailed scan_report.txt containing full paths to all detected threats.
3. 📊 Subscription Monitoring
Displays the current protection status and the remaining duration of the active license.
🛠️ Installation & Usage
Download the Security_Shield.bat file.
Run the file (Administrator privileges are required for "Fatal Destruction" to function properly).
Enter your personal access code.
Select the desired menu option.
⚠️ Disclaimer
The software is provided "as is". The developer is not responsible for files deleted by the user during "Fatal Destruction" or manual deletion based on the generated scan report.