@echo off
setlocal enabledelayedexpansion
title ❤️ Pulsing Protection
chcp 65001 >nul

:loop
:: Розовый (Маленькое сердце)
color 0d
cls
echo.
echo        **   **
echo       *  * *  *
echo        *  *  *
echo         *   *
echo           *
echo.
echo   Protection loves the world..
pathping 127.0.0.1 -n -q 1 -p 150 >nul

:: Красный (Большое сердце)
color 04
cls
echo.
echo       ***     ***
echo     **   ** **   **
echo    **     ***     **
echo     **           **
echo      **         **
echo        **     **
echo          ** **
echo            *
echo.
echo   Protection loves the world..
pathping 127.0.0.1 -n -q 1 -p 300 >nul

:: Фиолетовый (Большое сердце)
color 05
cls
echo.
echo       ***     ***
echo     **   ** **   **
echo    **     ***     **
echo     **           **
echo      **         **
echo        **     **
echo          ** **
echo            *
echo.
echo   Protection loves the world..
pathping 127.0.0.1 -n -q 1 -p 300 >nul

goto loop
