@echo off
setlocal enabledelayedexpansion
title Security Shield System v1.3
chcp 65001 >nul

:: Фикс путей (чтобы не вылетало при пробелах в имени пользователя)
set "root=%~dp0"
set "report_file=%root%scan_report.txt"

:auth
cls
color 09
echo.
echo          .----------.
echo         /    [==]    \
echo        ^|      /\      ^|      ------^>
echo        ^|     /  \     ^|
echo         \    \  /    /
echo          \    \/    /
echo           '--------'
echo.
echo     ВВЕДИТЕ КОД ДОСТУПА:
set /p "pass=> "

:: Проверка ключей (убрал тире в конце для стабильности, вводи как написано)
if "%pass%"=="N9sa-" (set "term=30 дней" & goto menu)
if "%pass%"=="Nopa233-" (set "term=90 дней" & goto menu)
if "%pass%"=="3333" (set "term=Навсегда" & goto menu)

echo [!] Неверный код.
timeout /t 2 >nul
goto auth

:menu
cls
color 0a
echo          .----------.
echo         /    [OK]    \
echo        ^|      /\      ^|      ------^>
echo ========================================
echo  1. Фатальное уничтожение угроз
echo  2. Сканер (Реальный поиск)
echo  3. Время подписки
echo  4. Выход
echo ========================================
echo СТАТУС: [%term%]
echo.
set /p "choice=Выбор: "

if "%choice%"=="1" goto fatal
if "%choice%"=="2" goto scan
if "%choice%"=="3" (cls & echo Срок: %term% & pause & goto menu)
if "%choice%"=="4" exit
goto menu

:fatal
cls
color 0c
echo [!] ЗАПУСК ФАТАЛЬНОГО УНИЧТОЖЕНИЯ...
echo ----------------------------------------
echo [1/3] Завершение процессов...
taskkill /f /im "wscript.exe" /t 2>nul
taskkill /f /im "cscript.exe" /t 2>nul
taskkill /f /im "powershell.exe" /t 2>nul

echo [2/3] Очистка автозагрузки...
del /f /q /s "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\*.*" 2>nul

echo [3/3] Очистка временных файлов (TEMP)...
del /f /q /s "%TEMP%\*.*" 2>nul

echo ----------------------------------------
echo [OK] Фатальная зачистка завершена.
pause
goto menu

:scan
cls
color 0b
echo [!] ЗАПУСК СКАНЕРА...
echo ----------------------------------------
set "found=0"
:: Маскировка сигнатур
set "s1=power" & set "s2=shell"
set "pats=%s1%%s2% bypass hidden Cookies LoginData WebData LocalState rmdir"

:: Сканируем только Рабочий стол (target)
for /r "%USERPROFILE%\Desktop" %%f in (*.exe *.bat *.py *.ps1 *.vbs *.cmd) do (
    if /i "%%f" neq "%~f0" (
        set "is_bad=0"
        for %%p in (%pats%) do (
            if "!is_bad!"=="0" (
                findstr /i /c:"%%p" "%%f" >nul 2>&1
                if !errorlevel! == 0 (
                    set "is_bad=1"
                    set /a "found+=1"
                    echo [КРИТИЧНО]: %%~nxf
                    echo [УГРОЗА]: %%f [Причина: %%p] >> "%report_file%"
                )
            )
        )
    )
)

echo ----------------------------------------
echo Сканирование окончено. Найдено: %found%
if %found% GTR 0 (
    start notepad "%report_file%"
)
pause
goto menu
